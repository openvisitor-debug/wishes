package com.aravind.lifeorganizer;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.view.*;import android.view.inputmethod.InputMethodManager;import android.widget.*;import java.util.*;

public class MainActivity extends Activity{
  String[] cats={"Need to Buy","Invest Ideas","Style Upgrades","Books to Read","Movies to Watch"};
  int selected=0; LinearLayout tabs,list; EditText input; SharedPreferences sp;
  public void onCreate(Bundle b){super.onCreate(b);sp=getSharedPreferences("items",0); build(); render();}
  TextView tv(String s,int size,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setPadding(18,14,18,14);return v;}
  void build(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(248,250,252));
    TextView title=tv("Life Organizer",26,Color.rgb(17,24,39));title.setTypeface(null,1);root.addView(title);
    tabs=new LinearLayout(this);tabs.setOrientation(LinearLayout.HORIZONTAL);tabs.setPadding(8,0,8,0);HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.addView(tabs);root.addView(hsv);
    LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);bar.setPadding(12,10,12,10);input=new EditText(this);input.setHint("Add item...");bar.addView(input,new LinearLayout.LayoutParams(0,-2,1));Button add=new Button(this);add.setText("Add");add.setOnClickListener(v->addItem());bar.addView(add);root.addView(bar);
    ScrollView sv=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(12,4,12,20);sv.addView(list);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
  void render(){tabs.removeAllViews(); for(int i=0;i<cats.length;i++){final int ix=i;TextView t=tv(cats[i],15,i==selected?Color.WHITE:Color.rgb(31,41,55));t.setBackgroundColor(i==selected?Color.rgb(17,24,39):Color.rgb(229,231,235));t.setOnClickListener(v->{selected=ix;render();});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.setMargins(4,4,4,4);tabs.addView(t,lp);} renderList();}
  String key(){return "cat_"+selected;} ArrayList<String> items(){String s=sp.getString(key(),"");ArrayList<String>a=new ArrayList<>();if(!s.isEmpty())a.addAll(Arrays.asList(s.split("\\n",-1)));return a;} void save(ArrayList<String>a){sp.edit().putString(key(),String.join("\n",a)).apply();}
  void addItem(){String s=input.getText().toString().trim(); if(s.isEmpty())return; ArrayList<String>a=items();a.add(s);save(a);input.setText("");((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0);renderList();}
  void renderList(){list.removeAllViews();ArrayList<String>a=items(); if(a.isEmpty()){TextView e=tv("No items yet. Add your first item above.",16,Color.rgb(107,114,128));list.addView(e);return;} for(int i=0;i<a.size();i++){final int ix=i;LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(4,6,4,6);TextView item=tv(a.get(i),17,Color.rgb(17,24,39));row.addView(item,new LinearLayout.LayoutParams(0,-2,1));Button del=new Button(this);del.setText("Done");del.setOnClickListener(v->{ArrayList<String>b=items();b.remove(ix);save(b);renderList();});row.addView(del);list.addView(row);}}
}
