# Life Organizer Native Android App

A single native Android app to track:
- Need to Buy
- Invest Ideas
- Style Upgrades
- Books to Read
- Movies to Watch

## Build APK
Open this folder in Android Studio, wait for Gradle Sync, then choose **Build > Build APK(s)**.
The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
